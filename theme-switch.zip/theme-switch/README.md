# Theme Switch

Based on [this](https://www.youtube.com/watch?v=rXuHGLzSmSE) video by fireship
